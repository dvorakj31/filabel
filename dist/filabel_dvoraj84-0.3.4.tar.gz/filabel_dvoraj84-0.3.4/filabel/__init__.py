from filabel.filabel import main
from filabel.web import app


__all__ = ['main', 'app']