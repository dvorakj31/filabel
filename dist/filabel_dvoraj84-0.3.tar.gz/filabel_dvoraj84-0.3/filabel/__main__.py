from filabel.filabel import main


main()